Use patch or keys from sublime3_keys.txt.

Patch variants:
1 (regular). You will see in the About:
Registered to
Unlimited User License

2 (with_PhoenixBBS_in_About). In the About will:
Registered to
PhoenixBBS

In this case, you can open sublime_text.exe in hex-editor, find ANSI-string 'PhoenixBBS' (of course, without the quotes) and
replace it to your name (must contain only English characters and the length should be no more than 'Unlimited User License').